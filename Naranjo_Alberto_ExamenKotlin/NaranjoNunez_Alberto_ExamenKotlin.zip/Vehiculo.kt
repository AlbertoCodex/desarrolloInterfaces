// Constructor principal
open class Vehiculo(var matricula:String, var marca:String, var modelo:String) {
    // Init para la variable Vendido
    init {
        var vendido:Boolean = false
    }
    open fun limitarVelocidad() {
        
    }
}

